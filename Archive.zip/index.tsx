import React, { useCallback, useMemo, useRef, useState } from 'react';
import {
  View,
  StyleSheet,
  ScrollView,
  useWindowDimensions,
  ViewProps,
} from 'react-native';
import type { ViewStyle, ScrollViewProps, StyleProp } from 'react-native';

import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { TabView, NavigationState } from 'react-native-tab-view';
import type { SceneRendererProps } from 'react-native-tab-view';

import Animated, {
  useAnimatedScrollHandler,
  useAnimatedStyle,
  useDerivedValue,
  useSharedValue,
} from 'react-native-reanimated';

import { Colors, Dimension } from '@deliveree/common_module';
import LocationsTab from '../LocationsTab';
import SummaryTab from '../SummaryTab';
import ItemTab from '../ItemTab';
import DetailHeader from '../components/DetailHeader';
import HeaderStatusInfo from '../components/HeaderStatusInfo';

import useScrollSync from './helper';
import type { HeaderConfig, RouteType, ScrollPair } from './helper';
import TabItem from './TabItem';
import AnimatedScrollView from './AnimatedScrollView';
import { DuplicateSaveBtn } from '../components/FooterButtons';
import ReimbursementAlert from '../components/ReimbursementAlert';
import { useRoute } from '@react-navigation/core';
import HandleReactNative from '@mari/helpers/ConnectNative/HandleReactNative';
import { MOENGAGE_EVT } from '@mari/constants/moengage';

const CombinedTab = ({ onRefresh }: { onRefresh: () => void }) => {
  const route: any = useRoute();

  const [activeIndex, setActiveIndex] = useState(
    route?.params?.activeIndex || 0
  );

  const { bottom } = useSafeAreaInsets();
  const { height: screenHeight } = useWindowDimensions();

  const [headerHeight, setHeaderHeight] = useState(0);

  const isScrolling = useSharedValue(false);

  const summaryRef = useRef<ScrollView>(null);
  const summaryScroll = useSharedValue(0);

  const summaryScrollHandler = useAnimatedScrollHandler((e) => {
    summaryScroll.value = e.contentOffset.y;
  });

  const packageRef = useRef<ScrollView>(null);
  const packageScroll = useSharedValue(0);
  const packageScrollHandler = useAnimatedScrollHandler(
    (e) => (packageScroll.value = e.contentOffset.y)
  );

  const locationRef = useRef<ScrollView>(null);
  const locationScroll = useSharedValue(0);
  const locationScrollHandler = useAnimatedScrollHandler(
    (e) => (locationScroll.value = e.contentOffset.y)
  );

  const scrollPairs = useMemo<ScrollPair[]>(
    () => [
      { list: summaryRef, position: summaryScroll },
      { list: packageRef, position: packageScroll },
      { list: locationRef, position: locationScroll },
    ],
    []
  );

  const handleHeaderLayout = useCallback<NonNullable<ViewProps['onLayout']>>(
    (event) => setHeaderHeight(event.nativeEvent.layout.height),
    []
  );

  const headerConfig = useMemo<HeaderConfig>(
    () => ({
      heightCollapsed: 0,
      heightExpanded: headerHeight,
    }),
    [headerHeight]
  );

  const { heightCollapsed, heightExpanded } = headerConfig;

  const headerDiff = heightExpanded - heightCollapsed;

  const { sync } = useScrollSync(scrollPairs, headerConfig);

  const currentScrollValue = useDerivedValue(() => {
    switch (activeIndex) {
      case 0:
        return summaryScroll.value;
      case 1:
        return packageScroll.value;
      case 2:
      default:
        return locationScroll.value;
    }
  }, [activeIndex]);

  const translateY = useDerivedValue(
    () => -Math.min(currentScrollValue.value, headerDiff)
  );

  const tabBarAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: translateY.value }],
  }));

  const headerAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: translateY.value }],
  }));

  const contentContainerStyle = useMemo<StyleProp<ViewStyle>>(
    () => ({
      //header height + tab height
      paddingTop: headerHeight + 60,
      paddingBottom: bottom,
      minHeight: screenHeight + 20,
    }),
    [bottom, screenHeight, headerHeight]
  );

  const sharedProps = useMemo<Partial<ScrollViewProps>>(
    () => ({
      contentContainerStyle,
      onMomentumScrollEnd: (e) => {
        sync(e, activeIndex);
        isScrolling.value = false;
      },
      onMomentumScrollBegin: () => {
        isScrolling.value = true;
      },
      onScrollEndDrag: (e) => {
        sync(e, activeIndex);
      },
      scrollEventThrottle: 16,
      keyboardShouldPersistTaps: 'handled',
      scrollIndicatorInsets: { top: heightExpanded },
    }),
    [contentContainerStyle, activeIndex, heightExpanded]
  );

  const onIndexChange = (index: number) => {
    if (isScrolling.value) {
      isScrolling.value = false;
      sync(
        {
          nativeEvent: {
            contentOffset: {
              y: Math.min(
                currentScrollValue.value,
                headerConfig.heightExpanded - headerConfig.heightCollapsed
              ),
            },
          },
        },
        activeIndex
      );
    }
    setActiveIndex(index);
  };

  const renderTabBar = ({
    navigationState,
  }: SceneRendererProps & {
    navigationState: NavigationState<RouteType>;
  }) => {
    const { routes } = navigationState;

    const onFocus = (idx) => () => {
      onIndexChange(idx);
      let getEventById = () => {
        switch (idx) {
          case 0:
            return MOENGAGE_EVT.SUMMARY_TAB;
          case 1:
            return MOENGAGE_EVT.PACKGAES_TAB;
          case 2:
            return MOENGAGE_EVT.LOCATIONS_TAB;
          default:
            return undefined;
        }
      };
      const event = getEventById();
      if (event) {
        HandleReactNative.trackMoengageEvent(event!);
      }
    };

    return (
      <Animated.View
        style={[
          { top: headerHeight },
          tabBarAnimatedStyle,
          styles.tabBarContainer,
        ]}
      >
        <View style={styles.tabBarWrapper}>
          {routes.map((item, idx) => (
            <TabItem
              key={idx}
              route={item}
              onFocus={onFocus(idx)}
              activeIndex={activeIndex}
              index={idx}
            />
          ))}
        </View>
      </Animated.View>
    );
  };

  const moveToTabTwo = useCallback(() => {
    setActiveIndex(1);
  }, []);

  const renderScene = ({
    route,
  }: SceneRendererProps & {
    route: RouteType;
  }) => {
    switch (route.key) {
      case ROUTE_STATE[0].key:
        return (
          <View style={styles.tabContainer}>
            <AnimatedScrollView
              onRefresh={onRefresh}
              ref={summaryRef}
              onScroll={summaryScrollHandler}
              {...sharedProps}
            >
              <SummaryTab
                moveTab={moveToTabTwo}
                scrollRef={summaryRef.current}
              />
            </AnimatedScrollView>
          </View>
        );

      case ROUTE_STATE[1].key:
        return (
          <View style={styles.tabContainer}>
            <AnimatedScrollView
              onRefresh={onRefresh}
              ref={packageRef}
              onScroll={packageScrollHandler}
              {...sharedProps}
            >
              <ItemTab />
            </AnimatedScrollView>
          </View>
        );

      case ROUTE_STATE[2].key:
        return (
          <View style={styles.tabContainer}>
            <AnimatedScrollView
              onRefresh={onRefresh}
              ref={locationRef}
              onScroll={locationScrollHandler}
              {...sharedProps}
            >
              <LocationsTab />
            </AnimatedScrollView>
          </View>
        );
      default:
        return null;
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: Colors.white }}>
      <View style={{ zIndex: 10 }}>
        <DetailHeader />
      </View>

      <View style={{ flex: 1, marginBottom: 48 + bottom }}>
        <Animated.View
          style={[styles.headerContainer, headerAnimatedStyle]}
          onLayout={handleHeaderLayout}
        >
          <HeaderStatusInfo />
          <ReimbursementAlert />
        </Animated.View>

        <TabView
          renderTabBar={renderTabBar}
          renderScene={renderScene}
          navigationState={{ index: activeIndex, routes: ROUTE_STATE }}
          onIndexChange={onIndexChange}
        />
      </View>
      <View style={{ position: 'absolute', bottom: bottom, left: 0, right: 0 }}>
        <DuplicateSaveBtn />
      </View>
    </View>
  );
};

const ROUTE_STATE = [
  { key: 'summary', title: 'summary' },
  { key: 'packages', title: 'package_plural' },
  { key: 'locations', title: 'locations' },
];

export default CombinedTab;

const styles = StyleSheet.create({
  tabContainer: {
    backgroundColor: Colors.white,
    borderRadius: 6,
    marginBottom: 0,
  },

  tabBarContainer: {
    left: 0,
    right: 0,
    position: 'absolute',
    zIndex: 1,
    backgroundColor: Colors.white,
    paddingVertical: 12,
  },
  tabBarWrapper: {
    flexDirection: 'row',
    backgroundColor: Colors.whiteFour,
    borderRadius: 6,
    padding: 2,
    marginHorizontal: Dimension.D2,
  },

  headerContainer: {
    top: 0,
    left: 0,
    right: 0,
    position: 'absolute',
    zIndex: 1,
  },
  tabItemContainer: {
    padding: Dimension.D1,
    flex: 1,
    backgroundColor: Colors.white,
  },
});
