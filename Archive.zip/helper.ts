import { RefObject } from 'react';
import { ScrollView } from 'react-native';

import Animated from 'react-native-reanimated';

export type HeaderConfig = {
  heightExpanded: number;
  heightCollapsed: number;
};

export type ScrollPair = {
  list: RefObject<ScrollView>;
  position: Animated.SharedValue<number>;
};

export type RouteType = {
  key: string;
  title: string;
};

const useScrollSync = (
  scrollPairs: ScrollPair[],
  headerConfig: HeaderConfig
) => {
  const sync = (event: any, activeIndex: number) => {
    const { y } = event.nativeEvent.contentOffset;

    const { heightCollapsed, heightExpanded } = headerConfig;

    const headerDiff = heightExpanded - heightCollapsed;

    scrollPairs.forEach(({ list, position }, index) => {
      if (index === activeIndex) return;
      const scrollPosition = position.value ?? 0;
      if (scrollPosition > headerDiff && y > headerDiff) {
        return;
      }

      list.current?.scrollTo({
        y: Math.min(y, headerDiff),
        animated: false,
      });
    });
  };

  return { sync };
};

export default useScrollSync;
