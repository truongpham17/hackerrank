import React from 'react';
import { StyleSheet, View } from 'react-native';
import { Colors, Dimension, Text, Touchable } from '@deliveree/common_module';
import { RouteType } from './helper';
import { translate } from '@mari/locales';

const TabItem = ({
  onFocus,
  route,
  activeIndex,
  index,
}: {
  onFocus: () => void;
  route: RouteType;
  activeIndex: number;
  index: number;
}) => {
  const isSelected = index === activeIndex;
  const showSeparator = index === 1;
  const showLeftSeparator = showSeparator && activeIndex === 2;
  const showRightSeparator = showSeparator && activeIndex === 0;
  return (
    <>
      {showSeparator && (
        <View style={[styles.separator, showLeftSeparator && styles.visible]} />
      )}

      <Touchable
        onPress={onFocus}
        style={[styles.tabItemWrap, isSelected && styles.active]}
      >
        <Text
          h6
          medium={isSelected}
          color={isSelected ? Colors.emeraldGreen : Colors.text}
        >
          {translate(route.title)}
        </Text>
      </Touchable>

      {showSeparator && (
        <View
          style={[styles.separator, showRightSeparator && styles.visible]}
        />
      )}
    </>
  );
};

export default TabItem;

const styles = StyleSheet.create({
  active: {
    borderColor: Colors.emeraldGreen,
    backgroundColor: Colors.grassTen,
    borderRadius: Dimension.D1,
  },
  tabItemWrap: {
    height: 32,
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
    borderWidth: 1,
    borderColor: 'transparent',
    flexDirection: 'row',
  },
  separator: {
    height: '90%',
    width: 1,
    backgroundColor: 'transparent',
    alignSelf: 'center',
  },
  visible: {
    backgroundColor: Colors.white,
  },
});
