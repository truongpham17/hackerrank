import React, { forwardRef } from 'react';
import { RefreshControl, ScrollView } from 'react-native';
import Animated from 'react-native-reanimated';

type AnimScrollViewProps = {
  children: React.ReactElement;
  onRefresh: () => void;
  onScroll: any;
};

const AnimScrollView = Animated.createAnimatedComponent(ScrollView);

const AnimatedScrollView = forwardRef<ScrollView, AnimScrollViewProps>(
  ({ children, onRefresh, onScroll, ...props }, ref) => {
    return (
      <AnimScrollView
        showsVerticalScrollIndicator={false}
        ref={ref}
        onScroll={onScroll}
        refreshControl={
          <RefreshControl
            refreshing={false}
            onRefresh={() =>
              setTimeout(() => {
                onRefresh();
              }, 100)
            }
          />
        }
        {...props}
      >
        {children}
      </AnimScrollView>
    );
  }
);

export default AnimatedScrollView;
